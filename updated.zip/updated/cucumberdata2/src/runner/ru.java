package runner;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
				features={"C:\\Users\\Admin\\eclipse-workspace\\madhu\\cucumberdata2\\scenario-feature\\a.Feature"}
				,glue="stepdef"
			    ,plugin = {"pretty", "html:target/akbar-report"}
				,monochrome=true
						)
public class ru 
{    

}

 